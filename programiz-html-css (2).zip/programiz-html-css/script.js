* {

    margin: 0;

    padding: 0;

    box-sizing: border-box;

    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;

}

body {

    background: linear-gradient(135deg, #0f2027, #203a43, #2c5364);

    color: #fff;

    line-height: 1.6;

}

.container {

    max-width: 1200px;

    margin: 0 auto;

    padding: 0 20px;

}

/* Header Section */

header {

    padding: 100px 0 50px;

    text-align: center;

}

.hello {

    font-size: 5rem;

    font-weight: 700;

    margin-bottom: 20px;

    color: #ff6b6b;

    text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);

}

.tagline {

    font-size: 1.8rem;

    margin-bottom: 40px;

    color: #f8f9fa;

}

.btn {

    display: inline-block;

    padding: 15px 40px;

    background: #ff6b6b;

    color: white;

    text-decoration: none;

    border-radius: 50px;

    font-weight: 600;

    font-size: 1.2rem;

    transition: all 0.3s ease;

    box-shadow: 0 4px 15px rgba(255, 107, 107, 0.4);

}

.btn:hover {

    transform: translateY(-5px);

    box-shadow: 0 8px 20px rgba(255, 107, 107, 0.6);

}

/* About Section */

.about {

    padding: 80px 0;

    text-align: center;

}

.section-title {

    font-size: 2.5

